Welcome
--------|
![](https://media.tenor.com/iVCiM9W7cvYAAAAd/welcome.gif)

# Spam-Wa
Script termux spam wa unlimited terbaru !

<details open><summary><code>Perintah Script?</code></summary>

```php
$ git clone https://github.com/Sxp-ID/spam-wa
$ cd spam-wa
$ make install
$ ./main

Atau bisa juga run script nya dg ketik perintah
$ make run
```
</details>

## Full tutorialnya?
- Link video v1 (old) <code><a href="https://youtu.be/R53d9-o7uh4?si=M-Cgwrp9l1o-BF5_">klik disini</a></code>
- Link video v2 (new) <code><a href="https://youtu.be/44HrDpRm3cE?si=ZRQnEceFsIzBh48N">klik disini</a></code>
- Subs yt admin <code><a href="https://youtube.com/@freetutorialofficial">FREE TUTORIAL</a></code>
<div align="center">

### Jgn lupa kasih star masbro !
</div>
