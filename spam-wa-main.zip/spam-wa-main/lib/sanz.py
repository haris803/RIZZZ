sanzexde = "Yg baca muka lu kek kontol awokawok!"
